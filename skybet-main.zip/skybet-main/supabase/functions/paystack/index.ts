import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const PAYSTACK_SECRET_KEY = Deno.env.get('PAYSTACK_SECRET_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, email, amount, reference, userId, phone, bankCode, accountNumber, accountName } = await req.json();
    
    console.log(`Paystack action: ${action}, amount: ${amount}, email: ${email}`);

    if (action === 'initialize') {
      // Initialize a Paystack transaction
      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          amount: amount * 100, // Paystack expects amount in kobo/cents
          currency: 'KES',
          callback_url: `${req.headers.get('origin')}/`,
          metadata: {
            user_id: userId,
            type: 'deposit',
          },
        }),
      });

      const data = await response.json();
      console.log('Paystack initialize response:', data);

      if (!data.status) {
        throw new Error(data.message || 'Failed to initialize transaction');
      }

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'verify') {
      // Verify a Paystack transaction
      const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
        },
      });

      const data = await response.json();
      console.log('Paystack verify response:', data);

      if (data.status && data.data.status === 'success') {
        // Update user balance in database
        const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
        
        const depositAmount = data.data.amount / 100; // Convert from kobo to KES
        const userIdFromMeta = data.data.metadata?.user_id;

        if (userIdFromMeta) {
          // Check if this transaction was already processed
          const { data: existingTx } = await supabase
            .from('transactions')
            .select('id')
            .eq('mpesa_receipt', reference)
            .single();

          if (!existingTx) {
            // Update balance
            const { data: balanceData, error: balanceError } = await supabase.rpc(
              'update_user_balance',
              { p_user_id: userIdFromMeta, p_amount: depositAmount }
            );

            if (balanceError) {
              console.error('Error updating balance:', balanceError);
            } else {
              console.log('Balance updated successfully:', balanceData);
            }

            // Record transaction
            const { error: txError } = await supabase.from('transactions').insert({
              user_id: userIdFromMeta,
              type: 'deposit',
              amount: depositAmount,
              status: 'completed',
              mpesa_receipt: reference,
              phone: data.data.customer?.email || '',
            });

            if (txError) {
              console.error('Error recording transaction:', txError);
            }
          }
        }
      }

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'get_banks') {
      // Get list of banks for Kenya
      const response = await fetch('https://api.paystack.co/bank?country=kenya', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
        },
      });

      const data = await response.json();
      console.log('Paystack banks response:', data);

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'verify_account') {
      // Verify bank account
      const response = await fetch(`https://api.paystack.co/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
        },
      });

      const data = await response.json();
      console.log('Paystack verify account response:', data);

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'withdraw') {
      const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

      // Check user balance first
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('balance')
        .eq('user_id', userId)
        .single();

      if (profileError || !profile) {
        throw new Error('Failed to fetch user profile');
      }

      if (profile.balance < amount) {
        throw new Error('Insufficient balance');
      }

      // For mobile money withdrawals (M-Pesa)
      if (phone && phone.startsWith('254')) {
        // Create transfer recipient for mobile money
        const recipientResponse = await fetch('https://api.paystack.co/transferrecipient', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            type: 'mobile_money',
            name: accountName || 'Withdrawal',
            account_number: phone,
            bank_code: 'MPESA', // M-Pesa code for Kenya
            currency: 'KES',
          }),
        });

        const recipientData = await recipientResponse.json();
        console.log('Transfer recipient response:', recipientData);

        if (!recipientData.status) {
          // Fall back to recording pending withdrawal
          console.log('Mobile money recipient creation failed, recording pending withdrawal');
          
          const { error: txError } = await supabase.from('transactions').insert({
            user_id: userId,
            type: 'withdrawal',
            amount: amount,
            status: 'pending',
            phone: phone,
          });

          if (txError) {
            console.error('Error recording withdrawal:', txError);
            throw new Error('Failed to process withdrawal');
          }

          // Deduct from balance
          const { data: balanceData, error: balanceError } = await supabase.rpc(
            'update_user_balance',
            { p_user_id: userId, p_amount: -amount }
          );

          if (balanceError) {
            console.error('Error updating balance:', balanceError);
            throw new Error('Failed to update balance');
          }

          return new Response(JSON.stringify({ 
            status: true, 
            message: 'Withdrawal request submitted. Processing within 24 hours.',
            data: { balance: balanceData, pending: true }
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Initiate transfer
        const transferResponse = await fetch('https://api.paystack.co/transfer', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            source: 'balance',
            amount: amount * 100, // Convert to kobo
            recipient: recipientData.data.recipient_code,
            reason: 'Game winnings withdrawal',
          }),
        });

        const transferData = await transferResponse.json();
        console.log('Transfer response:', transferData);

        if (transferData.status) {
          // Record successful withdrawal
          const { error: txError } = await supabase.from('transactions').insert({
            user_id: userId,
            type: 'withdrawal',
            amount: amount,
            status: transferData.data.status === 'success' ? 'completed' : 'processing',
            phone: phone,
            mpesa_receipt: transferData.data.transfer_code,
          });

          if (txError) {
            console.error('Error recording withdrawal:', txError);
          }

          // Deduct from balance
          const { data: balanceData, error: balanceError } = await supabase.rpc(
            'update_user_balance',
            { p_user_id: userId, p_amount: -amount }
          );

          if (balanceError) {
            console.error('Error updating balance:', balanceError);
            throw new Error('Failed to update balance');
          }

          return new Response(JSON.stringify({ 
            status: true, 
            message: 'Withdrawal initiated successfully',
            data: { 
              balance: balanceData, 
              transfer_code: transferData.data.transfer_code,
              status: transferData.data.status
            }
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        } else {
          throw new Error(transferData.message || 'Transfer failed');
        }
      }

      // For bank transfers
      if (bankCode && accountNumber) {
        // Create transfer recipient
        const recipientResponse = await fetch('https://api.paystack.co/transferrecipient', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            type: 'nuban',
            name: accountName || 'Withdrawal',
            account_number: accountNumber,
            bank_code: bankCode,
            currency: 'KES',
          }),
        });

        const recipientData = await recipientResponse.json();
        console.log('Bank recipient response:', recipientData);

        if (!recipientData.status) {
          throw new Error(recipientData.message || 'Failed to create transfer recipient');
        }

        // Initiate transfer
        const transferResponse = await fetch('https://api.paystack.co/transfer', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            source: 'balance',
            amount: amount * 100,
            recipient: recipientData.data.recipient_code,
            reason: 'Game winnings withdrawal',
          }),
        });

        const transferData = await transferResponse.json();
        console.log('Bank transfer response:', transferData);

        if (transferData.status) {
          // Record withdrawal
          const { error: txError } = await supabase.from('transactions').insert({
            user_id: userId,
            type: 'withdrawal',
            amount: amount,
            status: 'processing',
            phone: accountNumber,
            mpesa_receipt: transferData.data.transfer_code,
          });

          if (txError) {
            console.error('Error recording withdrawal:', txError);
          }

          // Deduct from balance
          const { data: balanceData, error: balanceError } = await supabase.rpc(
            'update_user_balance',
            { p_user_id: userId, p_amount: -amount }
          );

          if (balanceError) {
            throw new Error('Failed to update balance');
          }

          return new Response(JSON.stringify({ 
            status: true, 
            message: 'Bank transfer initiated',
            data: { balance: balanceData, transfer_code: transferData.data.transfer_code }
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        } else {
          throw new Error(transferData.message || 'Bank transfer failed');
        }
      }

      // Fallback: Record pending withdrawal for manual processing
      const { error: txError } = await supabase.from('transactions').insert({
        user_id: userId,
        type: 'withdrawal',
        amount: amount,
        status: 'pending',
        phone: phone || email || '',
      });

      if (txError) {
        console.error('Error recording withdrawal:', txError);
        throw new Error('Failed to process withdrawal');
      }

      // Deduct from balance
      const { data: balanceData, error: balanceError } = await supabase.rpc(
        'update_user_balance',
        { p_user_id: userId, p_amount: -amount }
      );

      if (balanceError) {
        console.error('Error updating balance:', balanceError);
        throw new Error('Failed to update balance');
      }

      console.log('Withdrawal processed, new balance:', balanceData);

      return new Response(JSON.stringify({ 
        status: true, 
        message: 'Withdrawal request submitted',
        data: { balance: balanceData }
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    console.error('Paystack function error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
