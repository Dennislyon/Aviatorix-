import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import GameCanvas from '@/components/game/GameCanvas';
import MultiplierDisplay from '@/components/game/MultiplierDisplay';
import BettingPanelSpribe from '@/components/game/BettingPanelSpribe';
import GameHistorySpribe from '@/components/game/GameHistorySpribe';
import BetsTabs from '@/components/game/BetsTabs';
import ChatPanel from '@/components/game/ChatPanel';
import TransactionHistory from '@/components/game/TransactionHistory';
import DepositModal from '@/components/modals/DepositModal';
import WithdrawModal from '@/components/modals/WithdrawModal';
import ProfileModal from '@/components/modals/ProfileModal';
import ProvablyFairModal from '@/components/modals/ProvablyFairModal';
import SettingsModal from '@/components/modals/SettingsModal';
import MenuModal from '@/components/modals/MenuModal';
import { useGameEngine } from '@/hooks/useGameEngine';
import { useAuth } from '@/hooks/useAuth';
import { useGameSounds } from '@/hooks/useGameSounds';
import { useProvablyFair } from '@/hooks/useProvablyFair';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Wallet, User, Menu, Settings, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Index = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, profile, loading, signOut, refetchProfile, isAuthenticated } = useAuth();
  const { playSound, toggleSound, isSoundEnabled } = useGameSounds();
  const { currentRound, roundHistory, clientSeed, generateNextRound, verifyRound, completeRound, updateClientSeed } = useProvablyFair();

  const {
    gameState,
    playerBet,
    balance,
    history,
    liveBets,
    placeBet,
    cashout,
  } = useGameEngine(user?.id, refetchProfile);

  const [showDeposit, setShowDeposit] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showProvablyFair, setShowProvablyFair] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const prevGameStateRef = useRef({ isActive: false, hasCrashed: false, countdown: 0 });

  const displayBalance = profile?.balance ?? balance;
  const displayUsername = profile?.username ?? 'Player';

  // Sound effects for game events
  useEffect(() => {
    const prev = prevGameStateRef.current;

    // Game started
    if (gameState.isActive && !prev.isActive) {
      playSound('fly');
    }

    // Game crashed
    if (gameState.hasCrashed && !prev.hasCrashed) {
      playSound('crash');
      completeRound();
    }

    // Countdown tick
    if (gameState.countdown > 0 && gameState.countdown !== prev.countdown) {
      playSound('countdown');
    }

    prevGameStateRef.current = {
      isActive: gameState.isActive,
      hasCrashed: gameState.hasCrashed,
      countdown: gameState.countdown,
    };
  }, [gameState.isActive, gameState.hasCrashed, gameState.countdown, playSound, completeRound]);

  // Handle Paystack callback
  useEffect(() => {
    const reference = searchParams.get('reference');
    if (reference && user) {
      verifyPayment(reference);
    }
  }, [searchParams, user]);

  const verifyPayment = async (reference: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('paystack', {
        body: {
          action: 'verify',
          reference,
        },
      });

      if (error) throw error;

      if (data.status && data.data?.status === 'success') {
        const amount = data.data.amount / 100;
        toast({
          title: "Deposit Successful!",
          description: `KES ${amount.toLocaleString()} added to your account`,
          className: "bg-success border-success",
        });
        playSound('win');
        await refetchProfile();
        window.history.replaceState({}, '', '/');
      }
    } catch (error) {
      console.error('Payment verification error:', error);
    }
  };

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate('/auth');
    }
  }, [loading, isAuthenticated, navigate]);

  const handlePlaceBet = async (amount: number, autoCashout: number | null) => {
    const success = await placeBet(amount, autoCashout);
    if (success) {
      playSound('bet');
      toast({
        title: "Bet Placed!",
        description: `KES ${amount} bet placed`,
      });
    }
  };

  const handleCashout = async () => {
    const success = await cashout();
    if (success && playerBet) {
      const winnings = playerBet.amount * gameState.multiplier;
      playSound('cashout');
      toast({
        title: "Cash Out!",
        description: `Won KES ${winnings.toFixed(2)} at ${gameState.multiplier.toFixed(2)}x`,
        className: "bg-success border-success",
      });
    }
  };

  const handleDeposit = () => {
    refetchProfile();
  };

  const handleWithdraw = (amount: number) => {
    refetchProfile();
    toast({
      title: "Withdrawal Initiated",
      description: `KES ${amount.toLocaleString()} withdrawal request submitted`,
    });
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  const handleToggleSound = (enabled: boolean) => {
    setSoundEnabled(enabled);
    toggleSound(enabled);
  };

  const handleMenuNavigate = (page: string) => {
    switch (page) {
      case 'provably-fair':
        setShowProvablyFair(true);
        break;
      case 'transactions':
        // Scroll to transaction history
        break;
      default:
        break;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-success" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden"
              onClick={() => setShowMenu(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-destructive to-orange-500 flex items-center justify-center">
                <span className="font-display font-bold text-sm text-white">A</span>
              </div>
              <span className="font-display font-bold text-lg hidden sm:block">AVIATOR</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Provably Fair */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowProvablyFair(true)}
              className="hidden sm:flex"
            >
              <Shield className="w-5 h-5 text-success" />
            </Button>

            {/* Settings */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSettings(true)}
            >
              <Settings className="w-5 h-5" />
            </Button>

            <div className="flex items-center gap-1 bg-secondary rounded-full px-3 py-1.5">
              <Wallet className="w-4 h-4 text-success" />
              <span className="font-bold text-sm">{displayBalance.toLocaleString()}</span>
            </div>

            <Button 
              size="sm"
              onClick={() => setShowDeposit(true)}
              className="bg-success hover:bg-success/90 text-success-foreground font-semibold"
            >
              Deposit
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowProfile(true)}
              className="rounded-full"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-success to-accent flex items-center justify-center">
                <User className="w-3 h-3 text-success-foreground" />
              </div>
            </Button>
          </div>
        </div>
      </header>

      <main className="pb-4">
        {/* Game History Strip */}
        <div className="bg-card/50 px-4 border-b border-border">
          <GameHistorySpribe history={history} />
        </div>

        <div className="container mx-auto px-4 pt-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Main Game Area */}
            <div className="lg:col-span-8 space-y-4">
              {/* Game Canvas */}
              <div className="spribe-card rounded-xl relative overflow-hidden min-h-[300px]">
                {/* Canvas background */}
                <GameCanvas
                  multiplier={gameState.multiplier}
                  isActive={gameState.isActive}
                  hasCrashed={gameState.hasCrashed}
                />

                {/* Countdown overlay */}
                {gameState.countdown > 0 && !gameState.isActive && (
                  <div className="absolute inset-0 flex items-center justify-center z-20 bg-background/90">
                    <div className="text-center">
                      <p className="text-muted-foreground text-sm uppercase tracking-wider mb-2">
                        Starting in
                      </p>
                      <div className="font-display text-6xl font-black text-foreground animate-pulse">
                        {gameState.countdown}
                      </div>
                    </div>
                  </div>
                )}

                {/* Multiplier Display */}
                <div className="absolute inset-0 flex flex-col items-center justify-center z-10 pointer-events-none">
                  {gameState.hasCrashed && (
                    <p className="text-muted-foreground uppercase tracking-wider mb-2 text-sm">
                      FLEW AWAY!
                    </p>
                  )}
                  
                  <MultiplierDisplay
                    multiplier={gameState.multiplier}
                    isActive={gameState.isActive}
                    hasCrashed={gameState.hasCrashed}
                  />
                </div>
              </div>

              {/* Dual Betting Panels */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <BettingPanelSpribe
                  balance={displayBalance}
                  onPlaceBet={handlePlaceBet}
                  onCashout={handleCashout}
                  isGameActive={gameState.isActive}
                  hasBet={!!playerBet && !playerBet.hasWon}
                  currentMultiplier={gameState.multiplier}
                  betAmount={playerBet?.amount || 0}
                  panelId={1}
                />
                <BettingPanelSpribe
                  balance={displayBalance}
                  onPlaceBet={handlePlaceBet}
                  onCashout={handleCashout}
                  isGameActive={gameState.isActive}
                  hasBet={false}
                  currentMultiplier={gameState.multiplier}
                  betAmount={0}
                  panelId={2}
                />
              </div>

              {/* Bets Tabs */}
              <BetsTabs liveBets={liveBets} currentMultiplier={gameState.multiplier} />
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-4 space-y-4">
              <ChatPanel />
              <TransactionHistory />
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <MenuModal
        open={showMenu}
        onClose={() => setShowMenu(false)}
        onNavigate={handleMenuNavigate}
        onSignOut={handleSignOut}
      />

      <SettingsModal
        open={showSettings}
        onClose={() => setShowSettings(false)}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      <ProvablyFairModal
        open={showProvablyFair}
        onClose={() => setShowProvablyFair(false)}
        currentRound={currentRound}
        roundHistory={roundHistory}
        clientSeed={clientSeed}
        onUpdateClientSeed={updateClientSeed}
        onVerifyRound={verifyRound}
      />

      <DepositModal
        open={showDeposit}
        onClose={() => setShowDeposit(false)}
        onDeposit={handleDeposit}
      />

      <WithdrawModal
        open={showWithdraw}
        onClose={() => setShowWithdraw(false)}
        balance={displayBalance}
        onWithdraw={handleWithdraw}
      />

      <ProfileModal
        open={showProfile}
        onClose={() => setShowProfile(false)}
        username={displayUsername}
        balance={displayBalance}
        stats={{
          totalGames: profile?.games_played ?? 0,
          totalWins: profile?.total_wins ?? 0,
          biggestMultiplier: 0,
          totalWinnings: profile?.total_bets ?? 0,
        }}
        onWithdrawClick={() => {
          setShowProfile(false);
          setShowWithdraw(true);
        }}
        onSignOut={handleSignOut}
      />
    </div>
  );
};

export default Index;
