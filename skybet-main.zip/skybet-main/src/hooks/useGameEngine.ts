import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { LiveBet } from '@/components/game/LiveBetsFeed';
import type { LeaderboardEntry } from '@/components/game/Leaderboard';

interface GameState {
  isActive: boolean;
  multiplier: number;
  hasCrashed: boolean;
  countdown: number;
  roundId: string | null;
}

interface PlayerBet {
  amount: number;
  autoCashout: number | null;
  hasWon: boolean;
  cashoutMultiplier: number | null;
}

const MOCK_USERNAMES = [
  'LuckyPlayer', 'CryptoKing', 'Betmaster', 'HighRoller', 'SafePlayer',
  'RiskTaker', 'AceGamer', 'NightOwl', 'FastCash', 'ProBetter'
];

const generateMockBets = (multiplier: number): LiveBet[] => {
  const count = Math.floor(Math.random() * 8) + 3;
  return Array.from({ length: count }, (_, i) => {
    const hasCashedOut = Math.random() > 0.6;
    const cashoutAt = hasCashedOut ? Math.random() * multiplier + 1 : null;
    return {
      id: `bet-${Date.now()}-${i}`,
      username: MOCK_USERNAMES[Math.floor(Math.random() * MOCK_USERNAMES.length)],
      amount: Math.floor(Math.random() * 900 + 100),
      cashoutAt,
      isActive: !hasCashedOut,
    };
  });
};

const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', username: 'MegaWinner', totalWins: 125000, biggestWin: 54.32, rank: 1 },
  { id: '2', username: 'LuckyStrike', totalWins: 98500, biggestWin: 42.15, rank: 2 },
  { id: '3', username: 'CashMaster', totalWins: 76200, biggestWin: 38.90, rank: 3 },
  { id: '4', username: 'ProGamer', totalWins: 54300, biggestWin: 28.45, rank: 4 },
  { id: '5', username: 'RiskTaker', totalWins: 43100, biggestWin: 22.30, rank: 5 },
];

export const useGameEngine = (userId?: string, onBalanceChange?: () => void) => {
  const [gameState, setGameState] = useState<GameState>({
    isActive: false,
    multiplier: 1.00,
    hasCrashed: false,
    countdown: 5,
    roundId: null,
  });

  const [playerBet, setPlayerBet] = useState<PlayerBet | null>(null);
  const [balance, setBalance] = useState(10000);
  const [history, setHistory] = useState<number[]>([2.34, 1.56, 5.67, 12.45, 1.23, 3.89, 8.90, 1.01, 4.56, 2.78]);
  const [liveBets, setLiveBets] = useState<LiveBet[]>([]);
  const [leaderboard] = useState<LeaderboardEntry[]>(MOCK_LEADERBOARD);

  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);
  const crashPointRef = useRef<number>(1);
  const currentBetIdRef = useRef<string | null>(null);

  const generateCrashPoint = () => {
    const e = 2.71828;
    const r = Math.random();
    return Math.max(1.00, Math.floor((Math.pow(e, r * 3)) * 100) / 100);
  };

  const startGame = useCallback(() => {
    crashPointRef.current = generateCrashPoint();
    const roundId = crypto.randomUUID();

    setGameState({
      isActive: true,
      multiplier: 1.00,
      hasCrashed: false,
      countdown: 0,
      roundId,
    });

    setLiveBets(generateMockBets(1.00));

    let currentMultiplier = 1.00;
    const speed = 0.02;

    gameLoopRef.current = setInterval(() => {
      currentMultiplier += speed * currentMultiplier * 0.1 + speed;
      currentMultiplier = Math.round(currentMultiplier * 100) / 100;

      if (currentMultiplier >= crashPointRef.current) {
        setGameState(prev => ({
          ...prev,
          multiplier: crashPointRef.current,
          hasCrashed: true,
          isActive: false,
        }));

        setHistory(prev => [crashPointRef.current, ...prev.slice(0, 19)]);

        // Handle player loss
        setPlayerBet(prev => {
          if (prev && !prev.hasWon) {
            // Record loss in database if we have user context
            if (userId && currentBetIdRef.current) {
              supabase
                .from('bets')
                .update({
                  status: 'lost',
                  payout: 0,
                })
                .eq('id', currentBetIdRef.current)
                .then(() => {
                  onBalanceChange?.();
                });
            }
            currentBetIdRef.current = null;
            return null;
          }
          return prev;
        });

        if (gameLoopRef.current) {
          clearInterval(gameLoopRef.current);
        }

        setTimeout(() => {
          let countdown = 5;
          setGameState(prev => ({ ...prev, countdown }));
          
          const countdownInterval = setInterval(() => {
            countdown--;
            setGameState(prev => ({ ...prev, countdown }));
            
            if (countdown <= 0) {
              clearInterval(countdownInterval);
              startGame();
            }
          }, 1000);
        }, 2000);
      } else {
        setGameState(prev => ({
          ...prev,
          multiplier: currentMultiplier,
        }));

        // Check auto cashout
        setPlayerBet(prev => {
          if (prev && prev.autoCashout && currentMultiplier >= prev.autoCashout && !prev.hasWon) {
            const winnings = prev.amount * prev.autoCashout;
            
            // Update balance in database
            if (userId && currentBetIdRef.current) {
              supabase.rpc('update_user_balance', {
                p_user_id: userId,
                p_amount: winnings
              }).then(() => {
                supabase
                  .from('bets')
                  .update({
                    status: 'won',
                    cashout_multiplier: prev.autoCashout,
                    payout: winnings,
                  })
                  .eq('id', currentBetIdRef.current)
                  .then(() => {
                    onBalanceChange?.();
                    currentBetIdRef.current = null;
                  });
              });
            } else {
              setBalance(b => b + winnings);
            }
            
            return {
              ...prev,
              hasWon: true,
              cashoutMultiplier: prev.autoCashout,
            };
          }
          return prev;
        });

        setLiveBets(prev => 
          prev.map(bet => {
            if (bet.isActive && Math.random() > 0.98) {
              return { ...bet, cashoutAt: currentMultiplier, isActive: false };
            }
            return bet;
          })
        );
      }
    }, 100);
  }, [userId, onBalanceChange]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      startGame();
    }, 2000);

    return () => {
      clearTimeout(timeout);
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [startGame]);

  const placeBet = useCallback(async (amount: number, autoCashout: number | null) => {
    if (gameState.isActive || amount > balance) return false;

    // Deduct from database if we have user context
    if (userId && gameState.roundId) {
      try {
        // Deduct balance
        const { error: balanceError } = await supabase.rpc('update_user_balance', {
          p_user_id: userId,
          p_amount: -amount
        });

        if (balanceError) {
          console.error('Balance update error:', balanceError);
          return false;
        }

        // Create bet record
        const { data: betData, error: betError } = await supabase
          .from('bets')
          .insert({
            user_id: userId,
            game_round: gameState.roundId,
            amount,
            status: 'active',
          })
          .select()
          .single();

        if (betError) {
          console.error('Bet creation error:', betError);
          // Refund balance
          await supabase.rpc('update_user_balance', {
            p_user_id: userId,
            p_amount: amount
          });
          return false;
        }

        currentBetIdRef.current = betData.id;
        onBalanceChange?.();
      } catch (error) {
        console.error('Bet placement error:', error);
        return false;
      }
    } else {
      setBalance(prev => prev - amount);
    }

    setPlayerBet({
      amount,
      autoCashout,
      hasWon: false,
      cashoutMultiplier: null,
    });

    return true;
  }, [gameState.isActive, gameState.roundId, balance, userId, onBalanceChange]);

  const cashout = useCallback(async () => {
    if (!gameState.isActive || !playerBet || playerBet.hasWon) return false;

    const winnings = playerBet.amount * gameState.multiplier;

    // Update database if we have user context
    if (userId && currentBetIdRef.current) {
      try {
        // Add winnings to balance
        const { error: balanceError } = await supabase.rpc('update_user_balance', {
          p_user_id: userId,
          p_amount: winnings
        });

        if (balanceError) {
          console.error('Balance update error:', balanceError);
          return false;
        }

        // Update bet record
        await supabase
          .from('bets')
          .update({
            status: 'won',
            cashout_multiplier: gameState.multiplier,
            payout: winnings,
          })
          .eq('id', currentBetIdRef.current);

        currentBetIdRef.current = null;
        onBalanceChange?.();
      } catch (error) {
        console.error('Cashout error:', error);
        return false;
      }
    } else {
      setBalance(prev => prev + winnings);
    }

    setPlayerBet(prev => prev ? {
      ...prev,
      hasWon: true,
      cashoutMultiplier: gameState.multiplier,
    } : null);

    return true;
  }, [gameState.isActive, gameState.multiplier, playerBet, userId, onBalanceChange]);

  return {
    gameState,
    playerBet,
    balance,
    setBalance,
    history,
    liveBets,
    leaderboard,
    placeBet,
    cashout,
  };
};
