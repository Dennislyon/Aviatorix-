import { useState, useCallback } from 'react';

interface GameRound {
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  crashPoint: number;
  hash: string;
}

const generateHash = async (input: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

const hashToCrashPoint = (hash: string): number => {
  const h = parseInt(hash.slice(0, 13), 16);
  const e = Math.pow(2, 52);
  const result = (100 * e - h) / (e - h);
  return Math.max(1.00, Math.floor(result) / 100);
};

export const useProvablyFair = () => {
  const [currentRound, setCurrentRound] = useState<GameRound | null>(null);
  const [roundHistory, setRoundHistory] = useState<GameRound[]>([]);
  const [clientSeed, setClientSeed] = useState(() => 
    Math.random().toString(36).substring(2, 15)
  );
  const [nonce, setNonce] = useState(0);

  const generateServerSeed = useCallback(() => {
    return crypto.randomUUID().replace(/-/g, '');
  }, []);

  const generateNextRound = useCallback(async (): Promise<GameRound> => {
    const serverSeed = generateServerSeed();
    const combinedSeed = `${serverSeed}:${clientSeed}:${nonce}`;
    const hash = await generateHash(combinedSeed);
    const crashPoint = hashToCrashPoint(hash);

    const round: GameRound = {
      serverSeed,
      clientSeed,
      nonce,
      crashPoint,
      hash,
    };

    setCurrentRound(round);
    setNonce(prev => prev + 1);

    return round;
  }, [clientSeed, nonce, generateServerSeed]);

  const verifyRound = useCallback(async (round: GameRound): Promise<boolean> => {
    const combinedSeed = `${round.serverSeed}:${round.clientSeed}:${round.nonce}`;
    const calculatedHash = await generateHash(combinedSeed);
    const calculatedCrashPoint = hashToCrashPoint(calculatedHash);
    
    return calculatedHash === round.hash && calculatedCrashPoint === round.crashPoint;
  }, []);

  const completeRound = useCallback(() => {
    if (currentRound) {
      setRoundHistory(prev => [currentRound, ...prev.slice(0, 49)]);
    }
  }, [currentRound]);

  const updateClientSeed = useCallback((newSeed: string) => {
    setClientSeed(newSeed);
    setNonce(0);
  }, []);

  return {
    currentRound,
    roundHistory,
    clientSeed,
    nonce,
    generateNextRound,
    verifyRound,
    completeRound,
    updateClientSeed,
  };
};
