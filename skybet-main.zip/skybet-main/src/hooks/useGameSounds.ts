import { useCallback, useRef, useEffect } from 'react';

type SoundType = 'fly' | 'crash' | 'bet' | 'cashout' | 'countdown' | 'win';

export const useGameSounds = () => {
  const audioContextRef = useRef<AudioContext | null>(null);
  const enabledRef = useRef(true);

  useEffect(() => {
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    return () => {
      audioContextRef.current?.close();
    };
  }, []);

  const playTone = useCallback((frequency: number, duration: number, type: OscillatorType = 'sine', volume = 0.1) => {
    if (!enabledRef.current || !audioContextRef.current) return;

    const ctx = audioContextRef.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = type;

    gainNode.gain.setValueAtTime(volume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
  }, []);

  const playSound = useCallback((sound: SoundType) => {
    if (!enabledRef.current) return;

    switch (sound) {
      case 'fly':
        // Rising tone for flying
        playTone(200, 0.1, 'sine', 0.05);
        setTimeout(() => playTone(250, 0.1, 'sine', 0.05), 50);
        break;

      case 'crash':
        // Explosion/crash sound
        playTone(200, 0.3, 'sawtooth', 0.15);
        playTone(100, 0.4, 'square', 0.1);
        setTimeout(() => playTone(80, 0.3, 'sawtooth', 0.08), 100);
        break;

      case 'bet':
        // Coin/chip sound
        playTone(800, 0.1, 'sine', 0.08);
        setTimeout(() => playTone(1000, 0.1, 'sine', 0.06), 50);
        break;

      case 'cashout':
        // Cash register/win sound
        playTone(523, 0.1, 'sine', 0.1);
        setTimeout(() => playTone(659, 0.1, 'sine', 0.1), 80);
        setTimeout(() => playTone(784, 0.15, 'sine', 0.1), 160);
        break;

      case 'countdown':
        // Beep for countdown
        playTone(440, 0.1, 'sine', 0.08);
        break;

      case 'win':
        // Victory fanfare
        playTone(523, 0.15, 'sine', 0.1);
        setTimeout(() => playTone(659, 0.15, 'sine', 0.1), 100);
        setTimeout(() => playTone(784, 0.15, 'sine', 0.1), 200);
        setTimeout(() => playTone(1047, 0.3, 'sine', 0.12), 300);
        break;
    }
  }, [playTone]);

  const toggleSound = useCallback((enabled: boolean) => {
    enabledRef.current = enabled;
  }, []);

  return { playSound, toggleSound, isSoundEnabled: () => enabledRef.current };
};
