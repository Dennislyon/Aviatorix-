import React, { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

interface GameCanvasProps {
  multiplier: number;
  isActive: boolean;
  hasCrashed: boolean;
  className?: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
}

const GameCanvas: React.FC<GameCanvasProps> = ({
  multiplier,
  isActive,
  hasCrashed,
  className,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const particlesRef = useRef<Particle[]>([]);
  const trailPointsRef = useRef<{ x: number; y: number; alpha: number }[]>([]);
  const timeRef = useRef(0);
  const propellerAngleRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const addParticle = (x: number, y: number, type: 'trail' | 'explosion') => {
      const colors = type === 'trail' 
        ? ['#f97316', '#facc15', '#ffffff', '#dc2626']
        : ['#ef4444', '#f97316', '#facc15', '#ffffff'];
      
      particlesRef.current.push({
        x,
        y,
        vx: (Math.random() - 0.5) * (type === 'explosion' ? 8 : 3),
        vy: (Math.random() - 0.5) * (type === 'explosion' ? 8 : 2) + (type === 'trail' ? 1 : 0),
        life: 1,
        maxLife: type === 'explosion' ? 60 : 30,
        size: Math.random() * (type === 'explosion' ? 6 : 4) + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    };

    const updateParticles = () => {
      particlesRef.current = particlesRef.current.filter(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 1 / p.maxLife;
        p.vy += 0.1; // gravity
        return p.life > 0;
      });
    };

    const drawParticles = (ctx: CanvasRenderingContext2D) => {
      particlesRef.current.forEach(p => {
        ctx.save();
        ctx.globalAlpha = p.life;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 10;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
    };

    const draw = () => {
      timeRef.current += 0.016;
      propellerAngleRef.current += 0.5;
      
      const width = canvas.offsetWidth;
      const height = canvas.offsetHeight;
      
      ctx.clearRect(0, 0, width, height);

      // Draw animated grid with pulse effect
      const pulseIntensity = 0.02 + Math.sin(timeRef.current * 2) * 0.01;
      ctx.strokeStyle = `rgba(255, 255, 255, ${pulseIntensity})`;
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x <= width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y <= height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Calculate progress based on multiplier
      const maxMultiplier = 15;
      const progress = Math.min((multiplier - 1) / (maxMultiplier - 1), 1);
      
      const padding = 50;
      const startX = padding;
      const startY = height - padding;
      
      // Smooth exponential curve calculation
      const curveProgress = Math.pow(progress, 0.6);
      const endX = startX + (width - padding * 2) * curveProgress;
      const endY = startY - (height - padding * 2) * curveProgress * 0.85;

      // Add wobble effect for more dynamic movement
      const wobbleX = Math.sin(timeRef.current * 8) * 2;
      const wobbleY = Math.cos(timeRef.current * 6) * 2;

      if (isActive || hasCrashed) {
        // Draw glow under curve
        const glowGradient = ctx.createRadialGradient(endX, endY, 0, endX, endY, 150);
        glowGradient.addColorStop(0, 'rgba(220, 38, 38, 0.2)');
        glowGradient.addColorStop(1, 'rgba(220, 38, 38, 0)');
        ctx.fillStyle = glowGradient;
        ctx.fillRect(0, 0, width, height);

        // Draw filled area under curve with gradient
        const gradient = ctx.createLinearGradient(startX, startY, endX, endY);
        gradient.addColorStop(0, 'rgba(220, 38, 38, 0.02)');
        gradient.addColorStop(0.5, 'rgba(220, 38, 38, 0.1)');
        gradient.addColorStop(1, 'rgba(220, 38, 38, 0.25)');

        ctx.beginPath();
        ctx.moveTo(startX, startY);
        
        const segments = 60;
        const curvePoints: { x: number; y: number }[] = [];
        
        for (let i = 0; i <= segments; i++) {
          const t = i / segments * curveProgress;
          const x = startX + (width - padding * 2) * t;
          const y = startY - (height - padding * 2) * Math.pow(t, 0.7) * 0.85;
          curvePoints.push({ x, y });
          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        
        ctx.lineTo(endX, height - padding);
        ctx.lineTo(startX, height - padding);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw glowing curve line
        ctx.save();
        ctx.shadowColor = '#dc2626';
        ctx.shadowBlur = 15;
        ctx.beginPath();
        curvePoints.forEach((point, i) => {
          if (i === 0) {
            ctx.moveTo(point.x, point.y);
          } else {
            ctx.lineTo(point.x, point.y);
          }
        });
        ctx.strokeStyle = hasCrashed ? '#ef4444' : '#dc2626';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
        ctx.restore();

        // Update trail points
        if (!hasCrashed && isActive) {
          trailPointsRef.current.push({ x: endX + wobbleX, y: endY + wobbleY, alpha: 1 });
          if (trailPointsRef.current.length > 20) {
            trailPointsRef.current.shift();
          }
          
          // Add trail particles
          if (Math.random() > 0.5) {
            addParticle(endX - 40, endY, 'trail');
          }
        }

        // Draw trail
        trailPointsRef.current.forEach((point, i) => {
          point.alpha -= 0.05;
          if (point.alpha > 0) {
            ctx.save();
            ctx.globalAlpha = point.alpha * 0.5;
            ctx.fillStyle = '#f97316';
            ctx.shadowColor = '#f97316';
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(point.x - 30, point.y, 3 + i * 0.3, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }
        });
        trailPointsRef.current = trailPointsRef.current.filter(p => p.alpha > 0);

        // Draw plane or explosion
        if (!hasCrashed) {
          drawEnhancedPlane(ctx, endX + wobbleX, endY + wobbleY, curveProgress);
        } else {
          // Add explosion particles
          if (particlesRef.current.length < 50) {
            for (let i = 0; i < 20; i++) {
              addParticle(endX, endY, 'explosion');
            }
          }
          drawEnhancedExplosion(ctx, endX, endY);
        }
      }

      // Update and draw particles
      updateParticles();
      drawParticles(ctx);

      // Draw axes labels
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.font = '11px "Roboto Condensed", sans-serif';
      ctx.textAlign = 'center';
      
      for (let i = 0; i <= 4; i++) {
        const x = padding + (width - padding * 2) * (i / 4);
        ctx.fillText(`${i * 5}s`, x, height - 20);
      }

      // Y-axis multiplier labels
      ctx.textAlign = 'right';
      for (let i = 0; i <= 4; i++) {
        const y = height - padding - (height - padding * 2) * (i / 4) * 0.85;
        const mult = 1 + (maxMultiplier - 1) * (i / 4);
        ctx.fillText(`${mult.toFixed(1)}x`, padding - 10, y + 4);
      }

      animationRef.current = requestAnimationFrame(draw);
    };

    const drawEnhancedPlane = (ctx: CanvasRenderingContext2D, x: number, y: number, progress: number) => {
      ctx.save();
      ctx.translate(x, y);
      
      // Calculate angle based on curve slope with smoother rotation
      const slope = 0.7 * Math.pow(Math.max(progress, 0.01), -0.3) * 0.85;
      const angle = -Math.atan(slope) * 0.5 - 0.15;
      ctx.rotate(angle);

      const scale = 1.3;

      // Draw engine exhaust trail
      ctx.save();
      for (let i = 0; i < 5; i++) {
        ctx.globalAlpha = (5 - i) / 10;
        ctx.fillStyle = i < 2 ? '#ffffff' : i < 4 ? '#facc15' : '#f97316';
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 15;
        const exhaustX = -35 * scale - i * 8;
        const exhaustY = Math.sin(propellerAngleRef.current + i) * 2;
        ctx.beginPath();
        ctx.ellipse(exhaustX, exhaustY, (12 - i * 2) * scale, (4 - i * 0.5) * scale, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Main plane glow
      ctx.shadowColor = '#dc2626';
      ctx.shadowBlur = 30;

      // Fuselage
      const fuselageGradient = ctx.createLinearGradient(-20 * scale, -8 * scale, -20 * scale, 8 * scale);
      fuselageGradient.addColorStop(0, '#ef4444');
      fuselageGradient.addColorStop(0.5, '#dc2626');
      fuselageGradient.addColorStop(1, '#b91c1c');
      
      ctx.fillStyle = fuselageGradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, 22 * scale, 9 * scale, 0, 0, Math.PI * 2);
      ctx.fill();

      // Nose cone
      ctx.beginPath();
      ctx.moveTo(18 * scale, 0);
      ctx.quadraticCurveTo(32 * scale, 0, 28 * scale, 0);
      ctx.lineTo(18 * scale, -4 * scale);
      ctx.closePath();
      ctx.fill();

      // Wings with gradient
      const wingGradient = ctx.createLinearGradient(0, -22 * scale, 0, 22 * scale);
      wingGradient.addColorStop(0, '#991b1b');
      wingGradient.addColorStop(0.5, '#b91c1c');
      wingGradient.addColorStop(1, '#991b1b');
      ctx.fillStyle = wingGradient;

      // Top wing
      ctx.beginPath();
      ctx.moveTo(-3 * scale, -4 * scale);
      ctx.lineTo(8 * scale, -24 * scale);
      ctx.lineTo(14 * scale, -22 * scale);
      ctx.lineTo(12 * scale, -4 * scale);
      ctx.closePath();
      ctx.fill();

      // Bottom wing  
      ctx.beginPath();
      ctx.moveTo(-3 * scale, 4 * scale);
      ctx.lineTo(8 * scale, 24 * scale);
      ctx.lineTo(14 * scale, 22 * scale);
      ctx.lineTo(12 * scale, 4 * scale);
      ctx.closePath();
      ctx.fill();

      // Tail fins
      ctx.fillStyle = '#7f1d1d';
      ctx.beginPath();
      ctx.moveTo(-18 * scale, 0);
      ctx.lineTo(-30 * scale, -12 * scale);
      ctx.lineTo(-24 * scale, -10 * scale);
      ctx.lineTo(-22 * scale, 0);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(-18 * scale, 0);
      ctx.lineTo(-30 * scale, 12 * scale);
      ctx.lineTo(-24 * scale, 10 * scale);
      ctx.lineTo(-22 * scale, 0);
      ctx.closePath();
      ctx.fill();

      // Cockpit window with animated reflection
      const reflectionOffset = Math.sin(timeRef.current * 3) * 2;
      ctx.fillStyle = '#fbbf24';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.ellipse(12 * scale, -2 * scale, 7 * scale, 4 * scale, -0.2, 0, Math.PI * 2);
      ctx.fill();

      // Window highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.ellipse(14 * scale + reflectionOffset, -4 * scale, 3 * scale, 1.5 * scale, -0.3, 0, Math.PI * 2);
      ctx.fill();

      // Propeller (animated)
      ctx.save();
      ctx.translate(28 * scale, 0);
      ctx.rotate(propellerAngleRef.current);
      ctx.fillStyle = '#4b5563';
      ctx.shadowBlur = 5;
      ctx.shadowColor = '#ffffff';
      
      for (let i = 0; i < 3; i++) {
        ctx.save();
        ctx.rotate((Math.PI * 2 / 3) * i);
        ctx.beginPath();
        ctx.ellipse(0, -8 * scale, 2 * scale, 8 * scale, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();

      ctx.restore();
    };

    const drawEnhancedExplosion = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
      ctx.save();
      ctx.translate(x, y);

      const time = timeRef.current * 10;
      
      // Shockwave rings
      for (let i = 0; i < 4; i++) {
        const radius = 30 + i * 20 + Math.sin(time + i * 0.5) * 10;
        const alpha = Math.max(0, 0.5 - i * 0.12);
        
        ctx.strokeStyle = `rgba(239, 68, 68, ${alpha})`;
        ctx.lineWidth = 4 - i * 0.8;
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Inner explosion glow
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, 50);
      gradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
      gradient.addColorStop(0.3, 'rgba(250, 204, 21, 0.6)');
      gradient.addColorStop(0.6, 'rgba(249, 115, 22, 0.4)');
      gradient.addColorStop(1, 'rgba(239, 68, 68, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(0, 0, 50, 0, Math.PI * 2);
      ctx.fill();

      // Explosion sparks
      for (let i = 0; i < 8; i++) {
        const sparkAngle = (Math.PI * 2 / 8) * i + time * 0.1;
        const sparkDist = 20 + Math.sin(time + i) * 15;
        const sparkX = Math.cos(sparkAngle) * sparkDist;
        const sparkY = Math.sin(sparkAngle) * sparkDist;
        
        ctx.fillStyle = i % 2 === 0 ? '#facc15' : '#f97316';
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(sparkX, sparkY, 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // "FLEW AWAY!" text
      ctx.fillStyle = '#ef4444';
      ctx.shadowColor = '#ef4444';
      ctx.shadowBlur = 20;
      ctx.font = 'bold 16px "Roboto Condensed", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('FLEW AWAY!', 0, 60);

      ctx.restore();
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [multiplier, isActive, hasCrashed]);

  return (
    <canvas
      ref={canvasRef}
      className={cn('w-full h-full absolute inset-0', className)}
    />
  );
};

export default GameCanvas;
