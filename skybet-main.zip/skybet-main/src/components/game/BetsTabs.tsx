import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

interface Bet {
  id: string;
  username: string;
  amount: number;
  multiplier?: number;
  hasWon?: boolean;
}

interface BetsTabsProps {
  liveBets: Bet[];
  currentMultiplier: number;
}

const BetsTabs: React.FC<BetsTabsProps> = ({ liveBets, currentMultiplier }) => {
  const [activeTab, setActiveTab] = useState('all');

  const topWinners = [...liveBets]
    .filter(b => b.hasWon)
    .sort((a, b) => ((b.multiplier || 1) * b.amount) - ((a.multiplier || 1) * a.amount))
    .slice(0, 10);

  return (
    <div className="spribe-card">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start bg-transparent border-b border-border rounded-none h-10 p-0">
          <TabsTrigger 
            value="all" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-success data-[state=active]:bg-transparent px-4"
          >
            All Bets
          </TabsTrigger>
          <TabsTrigger 
            value="previous" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-success data-[state=active]:bg-transparent px-4"
          >
            Previous
          </TabsTrigger>
          <TabsTrigger 
            value="top" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-success data-[state=active]:bg-transparent px-4"
          >
            Top
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="m-0">
          <div className="max-h-48 overflow-y-auto scrollbar-hide">
            {liveBets.length === 0 ? (
              <p className="p-4 text-center text-muted-foreground text-sm">No bets yet</p>
            ) : (
              liveBets.map((bet) => (
                <div key={bet.id} className="flex items-center justify-between px-3 py-2 border-b border-border/50 hover:bg-secondary/50">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-success to-accent flex items-center justify-center">
                      <span className="text-xs font-bold text-success-foreground">
                        {bet.username.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="text-sm text-foreground">{bet.username}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">
                      {bet.amount.toFixed(2)} KES
                    </p>
                    {bet.hasWon && bet.multiplier && (
                      <p className="text-xs text-success font-semibold">
                        {bet.multiplier.toFixed(2)}x
                      </p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="previous" className="m-0">
          <div className="p-4 text-center text-muted-foreground text-sm">
            Previous round bets will appear here
          </div>
        </TabsContent>

        <TabsContent value="top" className="m-0">
          <div className="max-h-48 overflow-y-auto scrollbar-hide">
            {topWinners.length === 0 ? (
              <p className="p-4 text-center text-muted-foreground text-sm">No winners yet</p>
            ) : (
              topWinners.map((bet, index) => (
                <div key={bet.id} className="flex items-center justify-between px-3 py-2 border-b border-border/50">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-4">{index + 1}</span>
                    <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                      <span className="text-xs font-bold text-white">
                        {bet.username.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="text-sm text-foreground">{bet.username}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-success">
                      {((bet.multiplier || 1) * bet.amount).toFixed(2)} KES
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BetsTabs;
