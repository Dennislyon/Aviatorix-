import React from 'react';
import { cn } from '@/lib/utils';

interface AviatorPlaneProps {
  isFlying: boolean;
  hasCrashed: boolean;
  className?: string;
}

const AviatorPlane: React.FC<AviatorPlaneProps> = ({ isFlying, hasCrashed, className }) => {
  return (
    <div
      className={cn(
        "relative transition-all duration-300",
        isFlying && !hasCrashed && "animate-float",
        hasCrashed && "animate-crash",
        className
      )}
    >
      {/* Plane glow effect */}
      <div className="absolute inset-0 blur-2xl bg-primary/40 rounded-full scale-150" />
      
      {/* Main plane body */}
      <svg
        width="120"
        height="80"
        viewBox="0 0 120 80"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 drop-shadow-2xl"
      >
        {/* Plane body */}
        <path
          d="M10 40C10 40 30 35 50 35C70 35 100 30 110 40C100 50 70 45 50 45C30 45 10 40 10 40Z"
          className="fill-primary"
        />
        
        {/* Cockpit */}
        <ellipse cx="95" cy="40" rx="12" ry="8" className="fill-accent" />
        <ellipse cx="98" cy="40" rx="6" ry="5" className="fill-foreground/20" />
        
        {/* Top wing */}
        <path
          d="M40 35L55 10L70 35"
          className="fill-primary/80 stroke-primary stroke-2"
        />
        
        {/* Bottom wing */}
        <path
          d="M40 45L55 70L70 45"
          className="fill-primary/80 stroke-primary stroke-2"
        />
        
        {/* Tail */}
        <path
          d="M15 40L5 25L25 35"
          className="fill-accent"
        />
        <path
          d="M15 40L5 55L25 45"
          className="fill-accent"
        />
        
        {/* Engine trail */}
        {isFlying && !hasCrashed && (
          <>
            <ellipse cx="8" cy="40" rx="10" ry="4" className="fill-orange-500/60" />
            <ellipse cx="2" cy="40" rx="6" ry="3" className="fill-yellow-400/40" />
            <ellipse cx="-5" cy="40" rx="4" ry="2" className="fill-red-500/30" />
          </>
        )}
      </svg>
      
      {/* Trail particles */}
      {isFlying && !hasCrashed && (
        <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-full">
          <div className="flex gap-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-2 h-2 rounded-full bg-primary/40 animate-pulse"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AviatorPlane;
