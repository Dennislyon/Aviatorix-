import React from 'react';
import { cn } from '@/lib/utils';

interface GameHistoryProps {
  history: number[];
}

const GameHistory: React.FC<GameHistoryProps> = ({ history }) => {
  const getMultiplierStyle = (mult: number) => {
    if (mult >= 10) return 'bg-gradient-to-r from-purple-500 to-pink-500 text-white';
    if (mult >= 5) return 'bg-gradient-to-r from-success to-emerald-400 text-success-foreground';
    if (mult >= 2) return 'bg-gradient-to-r from-primary to-accent text-primary-foreground';
    return 'bg-muted text-muted-foreground';
  };

  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
      <span className="text-xs text-muted-foreground uppercase tracking-wider whitespace-nowrap mr-2">
        Previous:
      </span>
      {history.slice(0, 20).map((mult, index) => (
        <div
          key={index}
          className={cn(
            "px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-300 hover:scale-110",
            getMultiplierStyle(mult)
          )}
        >
          {mult.toFixed(2)}x
        </div>
      ))}
    </div>
  );
};

export default GameHistory;
