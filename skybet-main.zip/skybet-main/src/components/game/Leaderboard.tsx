import React from 'react';
import { Trophy, Medal, Award, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface LeaderboardEntry {
  id: string;
  username: string;
  totalWins: number;
  biggestWin: number;
  rank: number;
}

interface LeaderboardProps {
  entries: LeaderboardEntry[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ entries }) => {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-5 h-5 text-yellow-400" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Award className="w-5 h-5 text-amber-600" />;
      default:
        return <span className="text-sm font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-500/20 to-amber-500/10 border-yellow-500/50';
      case 2:
        return 'bg-gradient-to-r from-gray-400/20 to-gray-500/10 border-gray-400/50';
      case 3:
        return 'bg-gradient-to-r from-amber-600/20 to-orange-600/10 border-amber-600/50';
      default:
        return 'bg-muted/30 border-border/50';
    }
  };

  return (
    <div className="glass-card rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-primary-foreground" />
        </div>
        <div>
          <h3 className="font-display text-lg font-bold">Leaderboard</h3>
          <p className="text-xs text-muted-foreground">Top Players Today</p>
        </div>
      </div>

      <div className="space-y-3">
        {entries.map((entry, index) => (
          <div
            key={entry.id}
            className={cn(
              "flex items-center justify-between p-4 rounded-xl border transition-all duration-300 hover:scale-[1.02] animate-fade-in",
              getRankStyle(entry.rank)
            )}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 flex items-center justify-center">
                {getRankIcon(entry.rank)}
              </div>
              <div>
                <p className="font-semibold text-foreground">{entry.username}</p>
                <p className="text-xs text-muted-foreground">
                  Best: <span className="text-success font-medium">{entry.biggestWin.toFixed(2)}x</span>
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-display font-bold text-primary">
                KES {entry.totalWins.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Total Wins</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Leaderboard;
