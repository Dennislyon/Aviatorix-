import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { Minus, Plus } from 'lucide-react';

interface BettingPanelProps {
  balance: number;
  onPlaceBet: (amount: number, autoCashout: number | null) => void;
  onCashout: () => void;
  isGameActive: boolean;
  hasBet: boolean;
  currentMultiplier: number;
  betAmount: number;
}

const BettingPanel: React.FC<BettingPanelProps> = ({
  balance,
  onPlaceBet,
  onCashout,
  isGameActive,
  hasBet,
  currentMultiplier,
  betAmount,
}) => {
  const [amount, setAmount] = useState<number>(100);
  const [autoCashout, setAutoCashout] = useState<string>('');

  const quickAmounts = [50, 100, 500, 1000];

  const adjustAmount = (delta: number) => {
    setAmount(Math.max(10, amount + delta));
  };

  const handlePlaceBet = () => {
    const autoVal = autoCashout ? parseFloat(autoCashout) : null;
    onPlaceBet(amount, autoVal);
  };

  const potentialWin = hasBet ? betAmount * currentMultiplier : 0;

  return (
    <div className="glass-card rounded-2xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <span className="text-muted-foreground text-sm uppercase tracking-wider">Bet Amount</span>
        <span className="text-foreground font-semibold">
          Balance: <span className="text-primary">KES {balance.toLocaleString()}</span>
        </span>
      </div>

      {/* Amount Input */}
      <div className="flex items-center gap-3">
        <Button
          variant="secondary"
          size="icon"
          onClick={() => adjustAmount(-10)}
          disabled={isGameActive && hasBet}
        >
          <Minus className="w-4 h-4" />
        </Button>
        
        <div className="relative flex-1">
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="text-center text-xl font-bold h-14 bg-secondary border-border"
            disabled={isGameActive && hasBet}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
            KES
          </span>
        </div>
        
        <Button
          variant="secondary"
          size="icon"
          onClick={() => adjustAmount(10)}
          disabled={isGameActive && hasBet}
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {/* Quick amounts */}
      <div className="grid grid-cols-4 gap-2">
        {quickAmounts.map((qa) => (
          <Button
            key={qa}
            variant="ghost"
            size="sm"
            onClick={() => setAmount(qa)}
            disabled={isGameActive && hasBet}
            className={cn(
              "text-xs",
              amount === qa && "bg-primary/20 text-primary border border-primary/50"
            )}
          >
            {qa}
          </Button>
        ))}
      </div>

      {/* Auto Cashout */}
      <div className="space-y-2">
        <span className="text-muted-foreground text-sm uppercase tracking-wider">
          Auto Cashout (optional)
        </span>
        <Input
          type="number"
          step="0.1"
          min="1.1"
          placeholder="e.g. 2.0"
          value={autoCashout}
          onChange={(e) => setAutoCashout(e.target.value)}
          className="bg-secondary border-border"
          disabled={isGameActive && hasBet}
        />
      </div>

      {/* Action Button */}
      {hasBet && isGameActive ? (
        <div className="space-y-3">
          <div className="text-center py-3 bg-success/10 rounded-lg border border-success/30">
            <span className="text-muted-foreground text-sm">Potential Win</span>
            <div className="text-2xl font-display font-bold text-success">
              KES {potentialWin.toFixed(2)}
            </div>
          </div>
          <Button
            variant="cashout"
            size="xl"
            className="w-full"
            onClick={onCashout}
          >
            Cash Out @ {currentMultiplier.toFixed(2)}x
          </Button>
        </div>
      ) : (
        <Button
          variant="game"
          size="xl"
          className="w-full"
          onClick={handlePlaceBet}
          disabled={isGameActive || amount > balance || amount < 10}
        >
          {isGameActive ? "Wait for next round" : `Place Bet - KES ${amount}`}
        </Button>
      )}
    </div>
  );
};

export default BettingPanel;
