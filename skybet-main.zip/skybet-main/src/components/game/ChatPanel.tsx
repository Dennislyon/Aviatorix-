import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, MessageCircle, Users, Smile, Trophy, Gift } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface ChatMessage {
  id: string;
  user_id: string;
  username: string;
  message: string;
  created_at: string;
}

const EMOJI_LIST = ['👍', '🔥', '🚀', '💰', '🎯', '💎', '⭐', '🎲', '🏆', '😎', '🤑', '💪'];
const QUICK_MESSAGES = [
  { text: 'Good luck everyone!', emoji: '🍀' },
  { text: "Let's go!", emoji: '🚀' },
  { text: 'Nice win!', emoji: '🎉' },
  { text: 'To the moon!', emoji: '🌙' },
];

const ChatPanel: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [onlineCount, setOnlineCount] = useState(0);
  const [showEmoji, setShowEmoji] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user, profile } = useAuth();

  useEffect(() => {
    fetchMessages();
    
    // Subscribe to new messages
    const channel = supabase
      .channel('chat-messages-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages'
        },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          setMessages(prev => {
            // Prevent duplicates
            if (prev.some(m => m.id === newMsg.id)) return prev;
            return [...prev, newMsg].slice(-100); // Keep last 100 messages
          });
        }
      )
      .subscribe();

    // Simulate online users (in production, use presence)
    const updateOnlineCount = () => {
      setOnlineCount(Math.floor(Math.random() * 50) + 120);
    };
    updateOnlineCount();
    const onlineInterval = setInterval(updateOnlineCount, 30000);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(onlineInterval);
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .order('created_at', { ascending: true })
      .limit(100);

    if (!error && data) {
      setMessages(data);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const sendMessage = async (text?: string) => {
    const messageText = text || newMessage.trim();
    if (!messageText || !user) return;

    setIsLoading(true);
    const { error } = await supabase.from('chat_messages').insert({
      user_id: user.id,
      username: profile?.username || 'Player',
      message: messageText,
    });

    if (!error) {
      setNewMessage('');
      setShowEmoji(false);
    }
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const addEmoji = (emoji: string) => {
    setNewMessage(prev => prev + emoji);
  };

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getMessageStyle = (msg: ChatMessage) => {
    // Highlight wins and special messages
    if (msg.message.toLowerCase().includes('win') || msg.message.includes('💰')) {
      return 'bg-success/10 border-l-2 border-success pl-2 -ml-2';
    }
    if (msg.message.includes('🚀') || msg.message.includes('moon')) {
      return 'bg-primary/10 border-l-2 border-primary pl-2 -ml-2';
    }
    return '';
  };

  const getRandomColor = (userId: string) => {
    const colors = ['text-success', 'text-primary', 'text-yellow-400', 'text-pink-400', 'text-cyan-400', 'text-orange-400'];
    const index = userId.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <div className="spribe-card h-96 flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-success" />
          <span className="text-sm font-semibold text-foreground">Live Chat</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
          </span>
          <Users className="w-3 h-3" />
          <span>{onlineCount} online</span>
        </div>
      </div>

      {/* Quick Messages */}
      <div className="px-3 py-2 border-b border-border flex gap-1.5 overflow-x-auto scrollbar-hide">
        {QUICK_MESSAGES.map((qm, i) => (
          <Button
            key={i}
            variant="ghost"
            size="sm"
            className="text-xs whitespace-nowrap bg-secondary/50 hover:bg-secondary h-7 px-2"
            onClick={() => sendMessage(`${qm.emoji} ${qm.text}`)}
            disabled={!user}
          >
            {qm.emoji} {qm.text}
          </Button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-hide">
        {messages.length === 0 && (
          <div className="text-center text-muted-foreground text-sm py-8">
            <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No messages yet</p>
            <p className="text-xs">Be the first to say hello!</p>
          </div>
        )}
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`text-sm rounded py-1 transition-colors ${getMessageStyle(msg)}`}
          >
            <span className="text-muted-foreground text-xs">{formatTime(msg.created_at)}</span>
            <span className={`font-medium ml-2 ${getRandomColor(msg.user_id)}`}>
              {msg.user_id === user?.id && <Trophy className="w-3 h-3 inline mr-1 text-yellow-400" />}
              {msg.username}:
            </span>
            <span className="text-foreground ml-1">{msg.message}</span>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-border space-y-2">
        {!user && (
          <div className="text-xs text-center text-muted-foreground bg-secondary/50 rounded py-2">
            <Gift className="w-4 h-4 inline mr-1" />
            Sign in to join the chat
          </div>
        )}
        <div className="flex gap-2">
          <Popover open={showEmoji} onOpenChange={setShowEmoji}>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0 bg-secondary"
                disabled={!user}
              >
                <Smile className="w-4 h-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-2" side="top" align="start">
              <div className="grid grid-cols-6 gap-1">
                {EMOJI_LIST.map((emoji) => (
                  <Button
                    key={emoji}
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-lg"
                    onClick={() => addEmoji(emoji)}
                  >
                    {emoji}
                  </Button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={user ? "Type a message..." : "Sign in to chat"}
            className="flex-1 bg-secondary border-border text-sm h-9"
            disabled={!user || isLoading}
            maxLength={200}
          />
          <Button
            size="sm"
            onClick={() => sendMessage()}
            disabled={!user || isLoading || !newMessage.trim()}
            className="bg-success hover:bg-success/90 h-9 px-3"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        {user && newMessage.length > 150 && (
          <p className="text-xs text-muted-foreground text-right">
            {200 - newMessage.length} characters left
          </p>
        )}
      </div>
    </div>
  );
};

export default ChatPanel;
