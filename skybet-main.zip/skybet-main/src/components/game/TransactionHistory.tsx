import React, { useState, useEffect } from 'react';
import { ArrowUpCircle, ArrowDownCircle, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  created_at: string;
  mpesa_receipt: string | null;
}

const TransactionHistory: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchTransactions();
    }
  }, [user]);

  const fetchTransactions = async () => {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false })
      .limit(20);

    if (!error && data) {
      setTransactions(data);
    }
    setIsLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-success" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-warning" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="spribe-card p-4">
        <div className="animate-pulse space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-12 bg-secondary rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="spribe-card">
      <div className="p-3 border-b border-border">
        <span className="text-sm font-semibold text-foreground">Transaction History</span>
      </div>

      <div className="max-h-64 overflow-y-auto scrollbar-hide">
        {transactions.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground text-sm">
            No transactions yet
          </div>
        ) : (
          transactions.map((tx) => (
            <div key={tx.id} className="p-3 border-b border-border/50 flex items-center gap-3 hover:bg-secondary/50">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                tx.type === 'deposit' ? 'bg-success/20' : 'bg-destructive/20'
              }`}>
                {tx.type === 'deposit' ? (
                  <ArrowDownCircle className="w-4 h-4 text-success" />
                ) : (
                  <ArrowUpCircle className="w-4 h-4 text-destructive" />
                )}
              </div>

              <div className="flex-1">
                <p className="text-sm font-medium text-foreground capitalize">{tx.type}</p>
                <p className="text-xs text-muted-foreground">{formatDate(tx.created_at)}</p>
              </div>

              <div className="text-right">
                <p className={`text-sm font-bold ${
                  tx.type === 'deposit' ? 'text-success' : 'text-destructive'
                }`}>
                  {tx.type === 'deposit' ? '+' : '-'}KES {tx.amount.toLocaleString()}
                </p>
                <div className="flex items-center justify-end gap-1">
                  {getStatusIcon(tx.status)}
                  <span className="text-xs text-muted-foreground capitalize">{tx.status}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TransactionHistory;
