import React from 'react';
import { cn } from '@/lib/utils';

interface MultiplierDisplayProps {
  multiplier: number;
  isActive: boolean;
  hasCrashed: boolean;
}

const MultiplierDisplay: React.FC<MultiplierDisplayProps> = ({
  multiplier,
  isActive,
  hasCrashed,
}) => {
  const getColor = () => {
    if (hasCrashed) return 'text-destructive';
    if (multiplier >= 10) return 'text-purple-400';
    if (multiplier >= 2) return 'text-success';
    return 'text-foreground';
  };

  return (
    <div className="text-center">
      <div
        className={cn(
          "font-display transition-all duration-100 tracking-tight",
          getColor(),
          isActive && "animate-multiplier",
          multiplier >= 5 ? "text-8xl md:text-9xl" : "text-7xl md:text-8xl"
        )}
        style={{
          fontWeight: 800,
          textShadow: hasCrashed 
            ? '0 0 60px hsl(0 84% 50% / 0.9), 0 0 120px hsl(0 84% 50% / 0.5)' 
            : multiplier >= 2 
              ? '0 0 60px hsl(142 70% 45% / 0.7), 0 0 120px hsl(142 70% 45% / 0.4)' 
              : '0 0 30px rgba(255,255,255,0.3)'
        }}
      >
        {multiplier.toFixed(2)}x
      </div>
    </div>
  );
};

export default MultiplierDisplay;
