import React from 'react';
import { cn } from '@/lib/utils';
import { User } from 'lucide-react';

export interface LiveBet {
  id: string;
  username: string;
  amount: number;
  cashoutAt: number | null;
  isActive: boolean;
}

interface LiveBetsFeedProps {
  bets: LiveBet[];
  currentMultiplier: number;
}

const LiveBetsFeed: React.FC<LiveBetsFeedProps> = ({ bets, currentMultiplier }) => {
  return (
    <div className="glass-card rounded-2xl p-4 h-full">
      <h3 className="text-sm uppercase tracking-wider text-muted-foreground mb-4 font-display">
        Live Bets
      </h3>
      
      <div className="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar">
        {bets.map((bet, index) => (
          <div
            key={bet.id}
            className={cn(
              "flex items-center justify-between p-3 rounded-lg transition-all duration-300 animate-slide-in-right",
              bet.cashoutAt
                ? "bg-success/10 border border-success/30"
                : bet.isActive
                ? "bg-primary/10 border border-primary/30"
                : "bg-muted/50 border border-border/50"
            )}
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                <User className="w-4 h-4 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{bet.username}</p>
                <p className="text-xs text-muted-foreground">KES {bet.amount.toLocaleString()}</p>
              </div>
            </div>
            
            <div className="text-right">
              {bet.cashoutAt ? (
                <>
                  <p className="text-sm font-bold text-success">{bet.cashoutAt.toFixed(2)}x</p>
                  <p className="text-xs text-success/80">
                    +KES {(bet.amount * bet.cashoutAt).toFixed(0)}
                  </p>
                </>
              ) : bet.isActive ? (
                <>
                  <p className="text-sm font-bold text-primary animate-pulse">
                    {currentMultiplier.toFixed(2)}x
                  </p>
                  <p className="text-xs text-primary/80">Playing...</p>
                </>
              ) : (
                <>
                  <p className="text-sm font-bold text-destructive">0.00x</p>
                  <p className="text-xs text-destructive/80">Crashed</p>
                </>
              )}
            </div>
          </div>
        ))}
        
        {bets.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No bets yet this round
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveBetsFeed;
