import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { Minus, Plus } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

interface BettingPanelSpribeProps {
  balance: number;
  onPlaceBet: (amount: number, autoCashout: number | null) => void;
  onCashout: () => void;
  isGameActive: boolean;
  hasBet: boolean;
  currentMultiplier: number;
  betAmount: number;
  panelId?: number;
}

interface AutoBetConfig {
  enabled: boolean;
  betAmount: number;
  autoCashout: number;
  stopOnWin: number;
  stopOnLoss: number;
  roundsPlayed: number;
  totalWon: number;
  totalLost: number;
}

const BettingPanelSpribe: React.FC<BettingPanelSpribeProps> = ({
  balance,
  onPlaceBet,
  onCashout,
  isGameActive,
  hasBet,
  currentMultiplier,
  betAmount,
  panelId = 1,
}) => {
  const [amount, setAmount] = useState<number>(10);
  const [mode, setMode] = useState<'bet' | 'auto'>('bet');
  const [autoCashout, setAutoCashout] = useState<string>('2.00');
  const [autoBetConfig, setAutoBetConfig] = useState<AutoBetConfig>({
    enabled: false,
    betAmount: 10,
    autoCashout: 2.0,
    stopOnWin: 100,
    stopOnLoss: 50,
    roundsPlayed: 0,
    totalWon: 0,
    totalLost: 0,
  });

  const quickAmounts = [10, 20, 50, 100];

  // Auto-bet logic
  useEffect(() => {
    if (mode === 'auto' && autoBetConfig.enabled && !isGameActive && !hasBet) {
      // Check stop conditions
      if (autoBetConfig.totalWon >= autoBetConfig.stopOnWin) {
        setAutoBetConfig(prev => ({ ...prev, enabled: false }));
        return;
      }
      if (autoBetConfig.totalLost >= autoBetConfig.stopOnLoss) {
        setAutoBetConfig(prev => ({ ...prev, enabled: false }));
        return;
      }

      // Place auto bet
      const timer = setTimeout(() => {
        if (autoBetConfig.betAmount <= balance) {
          onPlaceBet(autoBetConfig.betAmount, autoBetConfig.autoCashout);
          setAutoBetConfig(prev => ({
            ...prev,
            roundsPlayed: prev.roundsPlayed + 1,
          }));
        }
      }, 500);

      return () => clearTimeout(timer);
    }
  }, [isGameActive, hasBet, mode, autoBetConfig.enabled, balance]);

  const adjustAmount = (delta: number) => {
    setAmount(Math.max(1, amount + delta));
  };

  const handlePlaceBet = () => {
    const cashoutValue = autoCashout ? parseFloat(autoCashout) : null;
    onPlaceBet(amount, cashoutValue && cashoutValue > 1 ? cashoutValue : null);
  };

  const toggleAutoBet = () => {
    setAutoBetConfig(prev => ({
      ...prev,
      enabled: !prev.enabled,
      roundsPlayed: prev.enabled ? 0 : prev.roundsPlayed,
      totalWon: prev.enabled ? 0 : prev.totalWon,
      totalLost: prev.enabled ? 0 : prev.totalLost,
    }));
  };

  const potentialWin = hasBet ? betAmount * currentMultiplier : 0;

  return (
    <div className="spribe-card p-4 space-y-4">
      {/* Tabs */}
      <Tabs value={mode} onValueChange={(v) => setMode(v as 'bet' | 'auto')}>
        <TabsList className="grid grid-cols-2 w-full bg-secondary h-9">
          <TabsTrigger value="bet" className="text-sm data-[state=active]:bg-card">
            Bet
          </TabsTrigger>
          <TabsTrigger value="auto" className="text-sm data-[state=active]:bg-card">
            Auto
          </TabsTrigger>
        </TabsList>

        <TabsContent value="bet" className="mt-4">
          <div className="flex gap-3">
            {/* Amount Controls */}
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 bg-secondary hover:bg-muted"
                  onClick={() => adjustAmount(-10)}
                  disabled={isGameActive && hasBet}
                >
                  <Minus className="w-4 h-4" />
                </Button>
                
                <div className="flex-1 bg-secondary rounded-lg px-4 py-2 text-center">
                  <span className="text-lg font-bold text-foreground">{amount.toFixed(2)}</span>
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 bg-secondary hover:bg-muted"
                  onClick={() => adjustAmount(10)}
                  disabled={isGameActive && hasBet}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              {/* Quick amounts */}
              <div className="grid grid-cols-4 gap-1">
                {quickAmounts.map((qa) => (
                  <Button
                    key={qa}
                    variant="ghost"
                    size="sm"
                    onClick={() => setAmount(qa)}
                    disabled={isGameActive && hasBet}
                    className={cn(
                      "h-8 text-xs bg-secondary hover:bg-muted",
                      amount === qa && "bg-muted ring-1 ring-success/50"
                    )}
                  >
                    {qa}
                  </Button>
                ))}
              </div>

              {/* Auto Cashout */}
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground whitespace-nowrap">Auto:</Label>
                <Input
                  type="number"
                  step="0.1"
                  min="1.01"
                  value={autoCashout}
                  onChange={(e) => setAutoCashout(e.target.value)}
                  className="h-8 bg-secondary border-0 text-center text-sm"
                  placeholder="x"
                  disabled={isGameActive && hasBet}
                />
              </div>
            </div>

            {/* Action Button */}
            <div className="w-28">
              {hasBet && isGameActive ? (
                <Button
                  onClick={onCashout}
                  className="w-full h-full bg-warning hover:bg-warning/90 text-warning-foreground font-bold text-sm flex flex-col items-center justify-center rounded-lg"
                >
                  <span className="text-xs">CASH OUT</span>
                  <span className="text-base">{potentialWin.toFixed(2)}</span>
                </Button>
              ) : (
                <Button
                  onClick={handlePlaceBet}
                  disabled={isGameActive || amount > balance || amount < 1}
                  className={cn(
                    "w-full h-full font-bold text-sm flex flex-col items-center justify-center rounded-lg",
                    isGameActive 
                      ? "bg-muted text-muted-foreground cursor-not-allowed" 
                      : "bg-success hover:bg-success/90 text-success-foreground"
                  )}
                >
                  <span className="text-xs">BET</span>
                  <span className="text-base">{amount.toFixed(2)}</span>
                </Button>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="auto" className="mt-4 space-y-4">
          {/* Auto Bet Controls */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Bet Amount</Label>
              <Input
                type="number"
                min="1"
                value={autoBetConfig.betAmount}
                onChange={(e) => setAutoBetConfig(prev => ({
                  ...prev,
                  betAmount: parseFloat(e.target.value) || 10
                }))}
                className="h-9 bg-secondary border-0"
                disabled={autoBetConfig.enabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Auto Cashout</Label>
              <Input
                type="number"
                step="0.1"
                min="1.01"
                value={autoBetConfig.autoCashout}
                onChange={(e) => setAutoBetConfig(prev => ({
                  ...prev,
                  autoCashout: parseFloat(e.target.value) || 2.0
                }))}
                className="h-9 bg-secondary border-0"
                disabled={autoBetConfig.enabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Stop on Win</Label>
              <Input
                type="number"
                min="0"
                value={autoBetConfig.stopOnWin}
                onChange={(e) => setAutoBetConfig(prev => ({
                  ...prev,
                  stopOnWin: parseFloat(e.target.value) || 0
                }))}
                className="h-9 bg-secondary border-0"
                disabled={autoBetConfig.enabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Stop on Loss</Label>
              <Input
                type="number"
                min="0"
                value={autoBetConfig.stopOnLoss}
                onChange={(e) => setAutoBetConfig(prev => ({
                  ...prev,
                  stopOnLoss: parseFloat(e.target.value) || 0
                }))}
                className="h-9 bg-secondary border-0"
                disabled={autoBetConfig.enabled}
              />
            </div>
          </div>

          {/* Stats */}
          {autoBetConfig.enabled && (
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded bg-secondary">
                <p className="text-xs text-muted-foreground">Rounds</p>
                <p className="font-bold text-sm">{autoBetConfig.roundsPlayed}</p>
              </div>
              <div className="p-2 rounded bg-secondary">
                <p className="text-xs text-muted-foreground">Won</p>
                <p className="font-bold text-sm text-success">{autoBetConfig.totalWon.toFixed(0)}</p>
              </div>
              <div className="p-2 rounded bg-secondary">
                <p className="text-xs text-muted-foreground">Lost</p>
                <p className="font-bold text-sm text-destructive">{autoBetConfig.totalLost.toFixed(0)}</p>
              </div>
            </div>
          )}

          {/* Start/Stop Button */}
          <Button
            onClick={toggleAutoBet}
            className={cn(
              "w-full h-12 font-bold",
              autoBetConfig.enabled
                ? "bg-destructive hover:bg-destructive/90"
                : "bg-success hover:bg-success/90"
            )}
            disabled={autoBetConfig.betAmount > balance}
          >
            {autoBetConfig.enabled ? 'STOP AUTO BET' : 'START AUTO BET'}
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BettingPanelSpribe;
