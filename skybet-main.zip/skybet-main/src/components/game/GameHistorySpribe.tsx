import React from 'react';
import { cn } from '@/lib/utils';
import { History } from 'lucide-react';

interface GameHistorySpribeProps {
  history: number[];
}

const GameHistorySpribe: React.FC<GameHistorySpribeProps> = ({ history }) => {
  const getMultiplierStyle = (mult: number) => {
    if (mult >= 10) return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    if (mult >= 2) return 'bg-success/20 text-success border-success/30';
    return 'bg-secondary text-muted-foreground border-border';
  };

  return (
    <div className="flex items-center gap-2 overflow-x-auto py-3 scrollbar-hide">
      <div className="flex items-center gap-1 text-muted-foreground shrink-0">
        <History className="w-3.5 h-3.5" />
      </div>
      <div className="flex items-center gap-1.5">
        {history.slice(0, 15).map((mult, index) => (
          <span
            key={index}
            className={cn(
              "px-2 py-0.5 rounded-full text-xs font-bold border transition-all hover:scale-105",
              getMultiplierStyle(mult)
            )}
          >
            {mult.toFixed(2)}x
          </span>
        ))}
      </div>
    </div>
  );
};

export default GameHistorySpribe;
