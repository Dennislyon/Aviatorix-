import React from 'react';
import { Button } from '@/components/ui/button';
import { User, Wallet, Bell, Menu } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  balance: number;
  username: string;
  onProfileClick: () => void;
  onDepositClick: () => void;
}

const Header: React.FC<HeaderProps> = ({
  balance,
  username,
  onProfileClick,
  onDepositClick,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
              <span className="font-display font-black text-lg text-primary-foreground">A</span>
            </div>
            <div>
              <h1 className="font-display font-bold text-lg tracking-wider">AVIATOR</h1>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Crash Game</p>
            </div>
          </div>

          {/* Balance & Actions */}
          <div className="flex items-center gap-3">
            {/* Balance Display */}
            <div className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary border border-border">
              <Wallet className="w-4 h-4 text-primary" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Balance</p>
                <p className="font-display font-bold text-sm text-foreground">
                  KES {balance.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Deposit Button */}
            <Button variant="game" size="sm" onClick={onDepositClick}>
              <Wallet className="w-4 h-4" />
              <span className="hidden sm:inline">Deposit</span>
            </Button>

            {/* Notifications */}
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full text-[10px] flex items-center justify-center text-destructive-foreground">
                3
              </span>
            </Button>

            {/* Profile */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onProfileClick}
              className="rounded-full"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <User className="w-4 h-4 text-primary-foreground" />
              </div>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
