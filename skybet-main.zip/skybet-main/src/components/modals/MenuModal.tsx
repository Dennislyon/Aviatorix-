import React from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import {
  Home,
  History,
  Trophy,
  Shield,
  HelpCircle,
  MessageCircle,
  Wallet,
  Settings,
  LogOut,
} from 'lucide-react';

interface MenuModalProps {
  open: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  onSignOut: () => void;
}

const MenuModal: React.FC<MenuModalProps> = ({
  open,
  onClose,
  onNavigate,
  onSignOut,
}) => {
  const menuItems = [
    { icon: Home, label: 'Home', action: 'home' },
    { icon: History, label: 'Game History', action: 'history' },
    { icon: Trophy, label: 'Leaderboard', action: 'leaderboard' },
    { icon: Shield, label: 'Provably Fair', action: 'provably-fair' },
    { icon: Wallet, label: 'Transactions', action: 'transactions' },
    { icon: HelpCircle, label: 'How to Play', action: 'help' },
    { icon: MessageCircle, label: 'Support', action: 'support' },
  ];

  const handleClick = (action: string) => {
    onNavigate(action);
    onClose();
  };

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent side="left" className="bg-card border-border w-72">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-destructive to-orange-500 flex items-center justify-center">
              <span className="font-display font-bold text-sm text-white">A</span>
            </div>
            AVIATOR
          </SheetTitle>
        </SheetHeader>

        <div className="mt-8 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.action}
              onClick={() => handleClick(item.action)}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-secondary transition-colors text-left"
            >
              <item.icon className="w-5 h-5 text-muted-foreground" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}

          <div className="pt-4 border-t border-border mt-4">
            <button
              onClick={onSignOut}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-destructive/10 transition-colors text-destructive text-left"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sign Out</span>
            </button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default MenuModal;
