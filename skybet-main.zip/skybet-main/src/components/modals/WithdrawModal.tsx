import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Banknote, CheckCircle2, Loader2, Phone, Building2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface WithdrawModalProps {
  open: boolean;
  onClose: () => void;
  balance: number;
  onWithdraw: (amount: number) => void;
}

interface Bank {
  id: number;
  name: string;
  code: string;
}

const WithdrawModal: React.FC<WithdrawModalProps> = ({ open, onClose, balance, onWithdraw }) => {
  const [amount, setAmount] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  const [withdrawMethod, setWithdrawMethod] = useState<'mpesa' | 'bank'>('mpesa');
  const [banks, setBanks] = useState<Bank[]>([]);
  const [selectedBank, setSelectedBank] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [accountName, setAccountName] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open && withdrawMethod === 'bank' && banks.length === 0) {
      fetchBanks();
    }
  }, [open, withdrawMethod]);

  const fetchBanks = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('paystack', {
        body: { action: 'get_banks' },
      });

      if (!error && data.status && data.data) {
        setBanks(data.data);
      }
    } catch (error) {
      console.error('Error fetching banks:', error);
    }
  };

  const verifyAccount = async () => {
    if (!selectedBank || !accountNumber) return;

    setIsVerifying(true);
    try {
      const { data, error } = await supabase.functions.invoke('paystack', {
        body: {
          action: 'verify_account',
          bankCode: selectedBank,
          accountNumber: accountNumber,
        },
      });

      if (!error && data.status && data.data) {
        setAccountName(data.data.account_name);
        toast({
          title: "Account Verified",
          description: `Account name: ${data.data.account_name}`,
        });
      } else {
        toast({
          title: "Verification Failed",
          description: "Could not verify account. Please check the details.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error verifying account:', error);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleWithdraw = async () => {
    const withdrawAmount = Number(amount);
    
    if (!amount) {
      toast({
        title: "Missing Amount",
        description: "Please enter the withdrawal amount",
        variant: "destructive",
      });
      return;
    }

    if (withdrawMethod === 'mpesa' && !phone) {
      toast({
        title: "Missing Phone Number",
        description: "Please enter your M-Pesa phone number",
        variant: "destructive",
      });
      return;
    }

    if (withdrawMethod === 'bank' && (!selectedBank || !accountNumber)) {
      toast({
        title: "Missing Bank Details",
        description: "Please enter bank and account details",
        variant: "destructive",
      });
      return;
    }

    if (withdrawAmount > balance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough funds",
        variant: "destructive",
      });
      return;
    }

    if (withdrawAmount < 100) {
      toast({
        title: "Minimum Withdrawal",
        description: "Minimum withdrawal is KES 100",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setStep('processing');

    try {
      const { data: { user } } = await supabase.auth.getUser();

      const requestBody: Record<string, string | number | undefined> = {
        action: 'withdraw',
        amount: withdrawAmount,
        userId: user?.id,
      };

      if (withdrawMethod === 'mpesa') {
        requestBody.phone = phone.startsWith('254') ? phone : `254${phone.replace(/^0/, '')}`;
      } else {
        requestBody.bankCode = selectedBank;
        requestBody.accountNumber = accountNumber;
        requestBody.accountName = accountName;
      }

      const { data, error } = await supabase.functions.invoke('paystack', {
        body: requestBody,
      });

      if (error) throw error;

      if (data.status) {
        setStep('success');
        onWithdraw(withdrawAmount);

        setTimeout(() => {
          handleClose();
        }, 3000);
      } else {
        throw new Error(data.message || data.error || 'Withdrawal failed');
      }
    } catch (error: unknown) {
      console.error('Withdrawal error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to process withdrawal';
      toast({
        title: "Withdrawal Error",
        description: errorMessage,
        variant: "destructive",
      });
      setStep('form');
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setStep('form');
    setAmount('');
    setPhone('');
    setAccountNumber('');
    setAccountName('');
    setSelectedBank('');
    setIsLoading(false);
    onClose();
  };

  const quickAmounts = [500, 1000, 2000, 5000];

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="spribe-card border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
              <Banknote className="w-5 h-5 text-success" />
            </div>
            Withdraw Funds
          </DialogTitle>
        </DialogHeader>

        {step === 'form' && (
          <div className="space-y-5 pt-4">
            <div className="p-4 rounded-xl bg-secondary/50 border border-border">
              <p className="text-xs text-muted-foreground">Available Balance</p>
              <p className="text-2xl font-display font-bold text-success">
                KES {balance.toLocaleString()}
              </p>
            </div>

            <Tabs value={withdrawMethod} onValueChange={(v) => setWithdrawMethod(v as 'mpesa' | 'bank')}>
              <TabsList className="w-full grid grid-cols-2 bg-secondary">
                <TabsTrigger value="mpesa" className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  M-Pesa
                </TabsTrigger>
                <TabsTrigger value="bank" className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  Bank
                </TabsTrigger>
              </TabsList>

              <TabsContent value="mpesa" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">M-Pesa Phone Number</label>
                  <Input
                    type="tel"
                    placeholder="0712345678 or 254712345678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="bg-secondary border-border h-12"
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter your Safaricom M-Pesa number
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="bank" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Select Bank</label>
                  <Select value={selectedBank} onValueChange={setSelectedBank}>
                    <SelectTrigger className="bg-secondary border-border h-12">
                      <SelectValue placeholder="Choose your bank" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank.code} value={bank.code}>
                          {bank.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Account Number</label>
                  <div className="flex gap-2">
                    <Input
                      type="text"
                      placeholder="Enter account number"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      className="bg-secondary border-border h-12 flex-1"
                    />
                    <Button
                      variant="outline"
                      onClick={verifyAccount}
                      disabled={!selectedBank || !accountNumber || isVerifying}
                      className="h-12"
                    >
                      {isVerifying ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Verify'}
                    </Button>
                  </div>
                  {accountName && (
                    <p className="text-sm text-success">✓ {accountName}</p>
                  )}
                </div>
              </TabsContent>
            </Tabs>

            {/* Amount */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Amount (KES)</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary border-border h-12 text-lg font-bold"
              />
              
              {/* Quick amounts */}
              <div className="flex gap-2">
                {quickAmounts.map((amt) => (
                  <Button
                    key={amt}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmount(amt.toString())}
                    className="flex-1 text-xs"
                    disabled={amt > balance}
                  >
                    {amt.toLocaleString()}
                  </Button>
                ))}
              </div>

              <p className="text-xs text-muted-foreground">
                Min: KES 100 | Max: KES {balance.toLocaleString()}
              </p>
            </div>

            <Button
              className="w-full h-12 bg-success hover:bg-success/90 text-success-foreground font-bold"
              onClick={handleWithdraw}
              disabled={!amount || isLoading}
            >
              Withdraw KES {amount ? Number(amount).toLocaleString() : '0'}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              {withdrawMethod === 'mpesa' 
                ? 'M-Pesa withdrawals are instant'
                : 'Bank transfers take 1-3 business days'
              }
            </p>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-12 text-center space-y-4">
            <Loader2 className="w-16 h-16 text-success mx-auto animate-spin" />
            <h3 className="font-display text-lg">Processing Withdrawal</h3>
            <p className="text-muted-foreground text-sm">
              {withdrawMethod === 'mpesa' 
                ? 'Sending to your M-Pesa...'
                : 'Initiating bank transfer...'
              }
            </p>
          </div>
        )}

        {step === 'success' && (
          <div className="py-12 text-center space-y-4">
            <CheckCircle2 className="w-16 h-16 text-success mx-auto" />
            <h3 className="font-display text-lg text-success">Withdrawal Successful!</h3>
            <p className="text-muted-foreground text-sm">
              KES {Number(amount).toLocaleString()} 
              {withdrawMethod === 'mpesa' 
                ? ` sent to ${phone}`
                : ` will be credited to your bank account`
              }
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default WithdrawModal;
