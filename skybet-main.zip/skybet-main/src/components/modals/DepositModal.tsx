import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CreditCard, CheckCircle2, Loader2, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const PAYSTACK_PUBLIC_KEY = 'pk_live_68ff23270f50cf49966d3a25a07c35f94dc67fed';

interface DepositModalProps {
  open: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => void;
}

const DepositModal: React.FC<DepositModalProps> = ({ open, onClose, onDeposit }) => {
  const [amount, setAmount] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  const { toast } = useToast();

  const quickAmounts = [100, 500, 1000, 5000];

  const handleDeposit = async () => {
    if (!amount || !email) {
      toast({
        title: "Missing Information",
        description: "Please enter amount and email address",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setStep('processing');

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      
      // Initialize Paystack transaction
      const { data, error } = await supabase.functions.invoke('paystack', {
        body: {
          action: 'initialize',
          email,
          amount: Number(amount),
          userId: user?.id,
        },
      });

      if (error) throw error;

      if (data.status && data.data?.authorization_url) {
        // Redirect to Paystack checkout
        window.location.href = data.data.authorization_url;
      } else {
        throw new Error(data.message || 'Failed to initialize payment');
      }
    } catch (error: any) {
      console.error('Deposit error:', error);
      toast({
        title: "Payment Error",
        description: error.message || "Failed to initialize payment",
        variant: "destructive",
      });
      setStep('form');
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setStep('form');
    setAmount('');
    setEmail('');
    setIsLoading(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="glass-card border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-success" />
            </div>
            Deposit Funds
          </DialogTitle>
        </DialogHeader>

        {step === 'form' && (
          <div className="space-y-6 pt-4">
            {/* Email */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Email Address</label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-secondary border-border h-12"
              />
            </div>

            {/* Amount */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Amount (KES)</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary border-border h-12 text-lg font-bold"
              />
            </div>

            {/* Quick Amounts */}
            <div className="grid grid-cols-4 gap-2">
              {quickAmounts.map((qa) => (
                <Button
                  key={qa}
                  variant="ghost"
                  size="sm"
                  onClick={() => setAmount(qa.toString())}
                  className="text-sm"
                >
                  {qa}
                </Button>
              ))}
            </div>

            <Button
              variant="success"
              size="xl"
              className="w-full"
              onClick={handleDeposit}
              disabled={!amount || !email}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Pay with Paystack
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              You will be redirected to Paystack to complete payment securely
            </p>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-12 text-center space-y-4">
            <Loader2 className="w-16 h-16 text-primary mx-auto animate-spin" />
            <h3 className="font-display text-lg">Preparing Payment</h3>
            <p className="text-muted-foreground text-sm">
              Redirecting to Paystack...
            </p>
          </div>
        )}

        {step === 'success' && (
          <div className="py-12 text-center space-y-4">
            <CheckCircle2 className="w-16 h-16 text-success mx-auto" />
            <h3 className="font-display text-lg text-success">Deposit Successful!</h3>
            <p className="text-muted-foreground text-sm">
              KES {Number(amount).toLocaleString()} has been added to your account
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default DepositModal;
