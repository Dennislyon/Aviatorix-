import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  User, 
  Wallet, 
  History, 
  Trophy, 
  Settings, 
  LogOut,
  ChevronRight,
  TrendingUp,
  GamepadIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProfileModalProps {
  open: boolean;
  onClose: () => void;
  username: string;
  balance: number;
  stats: {
    totalGames: number;
    totalWins: number;
    biggestMultiplier: number;
    totalWinnings: number;
  };
  onWithdrawClick: () => void;
  onSignOut?: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({
  open,
  onClose,
  username,
  balance,
  stats,
  onWithdrawClick,
  onSignOut,
}) => {
  const menuItems = [
    { icon: History, label: 'Bet History', onClick: () => {} },
    { icon: Trophy, label: 'Achievements', onClick: () => {} },
    { icon: Settings, label: 'Settings', onClick: () => {} },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border max-w-md p-0 overflow-hidden">
        {/* Profile Header */}
        <div className="bg-gradient-to-br from-primary/20 to-accent/10 p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
              <User className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <h2 className="font-display text-xl font-bold">{username}</h2>
              <p className="text-sm text-muted-foreground">Premium Player</p>
            </div>
          </div>

          {/* Balance Card */}
          <div className="mt-6 p-4 rounded-xl bg-card/80 backdrop-blur border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Balance</p>
                <p className="text-2xl font-display font-bold text-foreground">
                  KES {balance.toLocaleString()}
                </p>
              </div>
              <Button variant="game" size="sm" onClick={onWithdrawClick}>
                <Wallet className="w-4 h-4 mr-2" />
                Withdraw
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="p-6 border-b border-border">
          <h3 className="text-sm uppercase tracking-wider text-muted-foreground mb-4">Your Stats</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-xl bg-secondary/50 border border-border">
              <GamepadIcon className="w-5 h-5 text-primary mb-2" />
              <p className="text-2xl font-display font-bold">{stats.totalGames}</p>
              <p className="text-xs text-muted-foreground">Total Games</p>
            </div>
            <div className="p-4 rounded-xl bg-secondary/50 border border-border">
              <Trophy className="w-5 h-5 text-success mb-2" />
              <p className="text-2xl font-display font-bold">{stats.totalWins}</p>
              <p className="text-xs text-muted-foreground">Total Wins</p>
            </div>
            <div className="p-4 rounded-xl bg-secondary/50 border border-border">
              <TrendingUp className="w-5 h-5 text-accent mb-2" />
              <p className="text-2xl font-display font-bold">{stats.biggestMultiplier.toFixed(2)}x</p>
              <p className="text-xs text-muted-foreground">Best Cashout</p>
            </div>
            <div className="p-4 rounded-xl bg-secondary/50 border border-border">
              <Wallet className="w-5 h-5 text-primary mb-2" />
              <p className="text-2xl font-display font-bold">
                {(stats.totalWinnings / 1000).toFixed(1)}K
              </p>
              <p className="text-xs text-muted-foreground">Total Winnings</p>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="p-4">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={item.onClick}
              className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-secondary transition-colors"
            >
              <div className="flex items-center gap-3">
                <item.icon className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium">{item.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
          
          <button 
            onClick={onSignOut}
            className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-destructive/10 transition-colors text-destructive"
          >
            <div className="flex items-center gap-3">
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sign Out</span>
            </div>
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProfileModal;
