import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Copy, Check, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface GameRound {
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  crashPoint: number;
  hash: string;
}

interface ProvablyFairModalProps {
  open: boolean;
  onClose: () => void;
  currentRound: GameRound | null;
  roundHistory: GameRound[];
  clientSeed: string;
  onUpdateClientSeed: (seed: string) => void;
  onVerifyRound: (round: GameRound) => Promise<boolean>;
}

const ProvablyFairModal: React.FC<ProvablyFairModalProps> = ({
  open,
  onClose,
  currentRound,
  roundHistory,
  clientSeed,
  onUpdateClientSeed,
  onVerifyRound,
}) => {
  const [newClientSeed, setNewClientSeed] = useState(clientSeed);
  const [copied, setCopied] = useState<string | null>(null);
  const [verifying, setVerifying] = useState<string | null>(null);

  const copyToClipboard = async (text: string, label: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(null), 2000);
  };

  const handleUpdateSeed = () => {
    if (newClientSeed.length >= 8) {
      onUpdateClientSeed(newClientSeed);
      toast.success('Client seed updated');
    } else {
      toast.error('Seed must be at least 8 characters');
    }
  };

  const handleVerify = async (round: GameRound) => {
    setVerifying(round.hash);
    const isValid = await onVerifyRound(round);
    setVerifying(null);
    
    if (isValid) {
      toast.success('Round verified successfully!');
    } else {
      toast.error('Verification failed');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-success" />
            Provably Fair
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Explanation */}
          <div className="p-4 rounded-lg bg-secondary/50">
            <p className="text-sm text-muted-foreground">
              Our game uses cryptographic hashing to ensure fairness. Each round's crash point is determined before bets are placed and can be verified using the server seed, client seed, and nonce.
            </p>
          </div>

          {/* Client Seed Settings */}
          <div className="space-y-3">
            <Label>Your Client Seed</Label>
            <div className="flex gap-2">
              <Input
                value={newClientSeed}
                onChange={(e) => setNewClientSeed(e.target.value)}
                placeholder="Enter your client seed"
                className="bg-secondary border-border"
              />
              <Button onClick={handleUpdateSeed} variant="outline">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Current Round */}
          {currentRound && (
            <div className="space-y-3">
              <Label>Current Round (Hidden until complete)</Label>
              <div className="p-4 rounded-lg bg-card border border-border space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Hash (SHA-256)</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(currentRound.hash, 'hash')}
                  >
                    {copied === 'hash' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  </Button>
                </div>
                <code className="text-xs break-all text-success">
                  {currentRound.hash.slice(0, 32)}...
                </code>
                <p className="text-xs text-muted-foreground">
                  Server seed will be revealed after crash
                </p>
              </div>
            </div>
          )}

          {/* Round History */}
          <div className="space-y-3">
            <Label>Previous Rounds (Verify)</Label>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {roundHistory.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No rounds yet
                </p>
              ) : (
                roundHistory.slice(0, 10).map((round, index) => (
                  <div
                    key={round.hash}
                    className="p-3 rounded-lg bg-secondary/50 border border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`font-display font-bold ${
                        round.crashPoint >= 2 ? 'text-success' : 'text-destructive'
                      }`}>
                        {round.crashPoint.toFixed(2)}x
                      </span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleVerify(round)}
                        disabled={verifying === round.hash}
                      >
                        {verifying === round.hash ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          'Verify'
                        )}
                      </Button>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-muted-foreground">
                        Server: {round.serverSeed.slice(0, 16)}...
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        Nonce: {round.nonce}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProvablyFairModal;
